/**
 * \file
 * \brief 
 * \author 
 * \version 0.1
 * \date 
 * 
 * \param[in] 
 * 
 * Subscribes to: <BR>
 *    ° 
 * 
 * Publishes to: <BR>
 *    ° 
 *
 * Description
 *
 */


//Cpp
#include <sstream>
#include <stdio.h>
#include <vector>
#include <iostream>
#include <stdlib.h>
#include <math.h>

//ROS
#include "ros/ros.h"
#include <tf/transform_listener.h>
//#include <geometry_msgs/PointStamped.h>
#include <geometry_msgs/Point.h>
#include <dual_planar_arm_msgs/DualArmIK.h>
// Include here the ".h" files corresponding to the topic type you use.
using namespace std;
int main (int argc, char** argv)
{

	//ROS Initialization
    ros::init(argc, argv, "left_arm_tracker");

    // Define your node handles: YOU NEED AT LEAST ONE !
    ros::NodeHandle nh_glob, nh_loc("~");

    // Declare your node's subscriptions and service clients
    //ros::service::waitForService("right_arm_IK_service");
    ros::ServiceClient right_joint = nh_glob.serviceClient<dual_planar_arm_msgs::DualArmIK>("right_arm_IK_service");
    dual_planar_arm_msgs::DualArmIK srv;
    right_joint.call(srv);
    // Declare your publishers here.
    //ros::Publisher pubjoint = nh_glob.advertise<sensor_msgs::JointState>("/joint_command",1);

    tf::TransformListener listener;
    //geometry_msgs::PoseStamped goalpos;
    geometry_msgs::Point goalpos;
    ros::Rate rate(50);   // Or other rate.
    while (ros::ok()){
        ros::spinOnce();

        // Your code here.
        tf::StampedTransform transform;
        try{
            listener.lookupTransform("r_arm_base", "goal", ros::Time(0), transform);
        }
        catch (tf::TransformException ex){
        ROS_ERROR("%s",ex.what());
        ros::Duration(3.0).sleep();
        }

        goalpos.x=transform.getOrigin().x();
        goalpos.y=transform.getOrigin().y();
        //std::cout<<"x = "<< goalpos.x <<" y = " << goalpos.y <<std::endl;

        if( !right_joint.exists() ){
            ROS_ERROR("Service does not exist.");
        }
        else
        {   srv.request.goal.header.frame_id="r_arm_base";
            srv.request.goal.point.x=goalpos.x;
            srv.request.goal.point.y=goalpos.y;

            if(!right_joint.call(srv)){
                ROS_ERROR("Call to service failed") ;
            }
            else
            {
                if(srv.response.solutions.size()!=0){
                    //std::cout<<"joint_name:"<<srv.response.solutions[0].header.name <<std::endl;
                    std::cout<<"q = "<< srv.response.solutions[0] <<std::endl;
                    //pubjoint.publish(srv.response.solutions[0]) ;
                }
                else{
                    std::cout<<"no solution"<<std::endl;
                }

            }
        }


        rate.sleep();
    }
}

