/**
 * \file
 * \brief 
 * \author 
 * \version 0.1
 * \date 
 * 
 * \param[in] 
 * 
 * Subscribes to: <BR>
 *    ° 
 * 
 * Publishes to: <BR>
 *    ° 
 *
 * Description
 *     
 */


//Cpp
#include <sstream>
#include <stdio.h>
#include <vector>
#include <iostream>
#include <stdlib.h>
#include <math.h>

//ROS
#include "ros/ros.h"

// Include here the ".h" files corresponding to the topic types you use.
#include <geometry_msgs/Pose2D.h>
#include <geometry_msgs/Twist.h>

// Your callback functions here if any. With a reasonable function name...
// ...
//
//
double dx;
double dy;
double alpha;
double p;
double kd=2.7;
double ka=2.9;
double d0=1;
geometry_msgs::Pose2D goalpos;
geometry_msgs::Twist followerspeed;
double limit_angle(double a){
    while( a >=  M_PI ) a -= 2*M_PI ;
    while( a <  -M_PI ) a += 2*M_PI ;
    return a ;
}
void leaderCallback(geometry_msgs::Pose2D leaderpos){
    // ... Callback function code
    goalpos=leaderpos;
}
void followerCallback(geometry_msgs::Pose2D followerpos){
    // ... Callback function code
    dx=goalpos.x-followerpos.x;
    dy=goalpos.y-followerpos.y;
    alpha=limit_angle(atan2(dy,dx)-followerpos.theta);
    p=dx*cos(limit_angle(followerpos.theta))+dy*sin(limit_angle(followerpos.theta))-d0;
}
// Take an angle to [-pi,pi[ interval whatever its initial value.

 
int main (int argc, char** argv)
{

	//ROS Initialization
    ros::init(argc, argv, "controller_1_node");

    // Define your node handles: YOU NEED AT LEAST ONE !
    ros::NodeHandle nh_glob, nh_loc("~") ;

    // Read the node parameters if any
    // ...

    // Declare your node's subscriptions and service clients
    // A subscriber looks like this:
    ros::Subscriber leadersub = nh_glob.subscribe<geometry_msgs::Pose2D>("/robot1/pose",1,leaderCallback) ;
    ros::Subscriber followersub = nh_glob.subscribe<geometry_msgs::Pose2D>("/robot2/pose",1,followerCallback) ;


    // Declare you publishers and service servers
    // Publisher looks like this: 
    ros::Publisher pubfollower = nh_glob.advertise<geometry_msgs::Twist>("/robot2/cmd",1) ;
    
    // Intializations may be required here.
    // ...
     followerspeed.linear.x=0;
     followerspeed.angular.z=0;
    ros::Rate rate(50);   // Or other rate.
    while (ros::ok()){
        ros::spinOnce();

        // The code of your node goes here.
        followerspeed.linear.x=kd*p;
        followerspeed.angular.z=ka*alpha;
        pubfollower.publish(followerspeed);
        rate.sleep();
    }
}

