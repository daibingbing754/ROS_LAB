/**
 * \file
 * \brief 
 * \author 
 * \version 0.1
 * \date 
 * 
 * \param[in] 
 * 
 * Subscribes to: <BR>
 *    ° 
 * 
 * Publishes to: <BR>
 *    ° 
 *
 * Description
 *     
 */


//Cpp
#include <sstream>
#include <stdio.h>
#include <vector>
#include <iostream>
#include <stdlib.h>
#include <math.h>

//ROS
#include "ros/ros.h"

// Include here the ".h" files corresponding to the topic types you use.
// ...
#include <geometry_msgs/Pose2D.h>
#include <geometry_msgs/Twist.h>
#include <tf/transform_listener.h>
// Your callback functions here if any. With a reasonable function name...
// ...
//
//void myFirstCallback(/* Define here the variable which holds the message */){
//    // ... Callback function code
//}


// Take an angle to [-pi,pi[ interval whatever its initial value.
double limit_angle(double a){
    while( a >=  M_PI ) a -= 2*M_PI ;
    while( a <  -M_PI ) a += 2*M_PI ;
    return a ;
}
 
int main (int argc, char** argv)
{

	//ROS Initialization
    ros::init(argc, argv, "controller_1_node");

    // Define your node handles: YOU NEED AT LEAST ONE !
    ros::NodeHandle nh_glob, nh_loc("~") ;

    // Read the node parameters if any
    // ...

    // Declare your node's subscriptions and service clients
    // A subscriber looks like this:
    // ros::Subscriber subsName = some_node_handler.subscribe<pacakage::Type>("topic_name_here",buffer_size_often_1,yourCallBackFn) ;
    // ...

    // Declare you publishers and service servers
    // Publisher looks like this: 
    // ros::Publisher pubName = nh_glob.advertise<geometry_msgs::Twist>("/robot2/cmd",1) ;
    
    // Intializations may be required here.
    // ...
        
    ros::Rate rate(50);   // Or other rate.
    while (ros::ok()){
        ros::spinOnce();

        // The code of your node goes here.
        
        rate.sleep();
    }
}

