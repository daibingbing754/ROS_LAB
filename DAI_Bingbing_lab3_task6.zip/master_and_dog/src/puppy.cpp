/**
 * \file
 * \brief 
 * \author 
 * \version 0.1
 * \date 
 * 
 * \param[in] 
 * 
 * Subscribes to: <BR>
 *    ° 
 * 
 * Publishes to: <BR>
 *    ° 
 *
 * Description
 *
 */


//Cpp
#include <sstream>
#include <stdio.h>
#include <vector>
#include <iostream>
#include <stdlib.h>
#include <math.h>

//ROS
#include "ros/ros.h"

// Include here the ".h" files corresponding to the topic type you use.
// ...
#include <std_msgs/Int16.h>
#include <visualization_msgs/Marker.h>

#include <geometry_msgs/Point.h>
#include <std_msgs/Float64.h>

// You may have a number of globals here.
//...

 geometry_msgs::Point puppyPosition ;
 double ux=0;
 double uy=0;
 double ux_vector=0;
 double uy_vector=0;
// Callback functions...
//bool virtualLeaderInfoReceived     = false ;
void dogposCallback(geometry_msgs::Point dog){
    // ... Callback function code
    ux=dog.x-puppyPosition.x;
    uy=dog.y-puppyPosition.y;
    ux_vector=ux/sqrt(pow(ux,2)+pow(uy,2));
    uy_vector=uy/sqrt(pow(ux,2)+pow(uy,2));

//    virtualLeaderInfoReceived = true ;
}

//bool virtualLeaderSpeedInfoReceived     = false ;
std_msgs::Float64 puppySpeed;
void dogspeedCallback(std_msgs::Float64 dogSpeed ){
    // ... Callback function code
     puppySpeed.data=dogSpeed.data;
//    virtualLeaderSpeedInfoReceived = true ;
}

ros::Publisher pubMarker ;
visualization_msgs::Marker marker;

void initializeMarker(){
    // Fetch node name. Markers will be blue if the word "blue" is in the name, red otherwise.
    std::string nodeName ;
    nodeName = ros::this_node::getName();
    // Create a marker for this node. Only timestamp and position will be later updated.
    marker.header.frame_id = "/map";
    marker.ns = nodeName;
    marker.id = 0;
    marker.type = visualization_msgs::Marker::CUBE;
    marker.action = visualization_msgs::Marker::ADD;
    marker.pose.position.z = 0;
    marker.pose.orientation.x = 0.0;
    marker.pose.orientation.y = 0.0;
    marker.pose.orientation.z = 0.0;
    marker.pose.orientation.w = 1.0;
    marker.scale.x = 0.1;
    marker.scale.y = 0.1;
    marker.scale.z = 0.1;
    marker.color.r = 0.0f;
    marker.color.g = 1.0f;
    marker.color.b = 0.0f;
    marker.color.a = 1.0;
}


// Function to publish a marke at a given (x,y) position.

void publishMarkerAt( geometry_msgs::Point markerPos) {
    marker.header.stamp = ros::Time::now();
    marker.pose.position.x = markerPos.x ;
    marker.pose.position.y = markerPos.y ;
    marker.lifetime = ros::Duration();
    pubMarker.publish(marker);
}


int main (int argc, char** argv)
{

    //ROS Initialization
    ros::init(argc, argv, "puppy");

    // Define your node handles
    // Define your node handles
    ros::NodeHandle nh_loc("~") ;
    ros::NodeHandle nh_glob ;
    ros::NodeHandle nh_;
    // Read the node parameters if any
    // ...

    // Declare your node's subscriptions and service clients
    // ...
    ros::Subscriber posSub = nh_glob.subscribe<geometry_msgs::Point>("/dog_pos",1,dogposCallback) ;
    ros::Subscriber speedSub = nh_glob.subscribe<std_msgs::Float64>("/dog_speed",1,dogspeedCallback) ;
    // Declare you publishers and service servers
    // ...
    ros::Publisher pubPos = nh_glob.advertise<geometry_msgs::Point>("/puppy_pos",1);
    ros::Publisher pubSpeed = nh_glob.advertise<std_msgs::Float64>("/puppy_speed",1);
                   pubMarker         = nh_glob.advertise<visualization_msgs::Marker>("/visualization_marker",1) ;
double puppyx,puppyy;
   if(!nh_.getParam("/puppy2/puppyx",puppyx)){
       ROS_INFO("could not find parameter:puppyx\n");
               return 1;
   }
   else{
       ROS_INFO("Robot name: %lf\n",puppyx);
   }

   if(!nh_.getParam("/puppy2/puppyy",puppyy)){
       ROS_INFO("could not find parameter:puppyy\n");
               return 1;
   }
   else{
       ROS_INFO("Robot name: %lf\n",puppyy);
   }

    puppyPosition.x = puppyx ;
    puppyPosition.y = puppyy;
    puppyPosition.z = 0.0 ;

    //new

    //double speed     = 1.0 ;
    //new
    //dogSpeed.data=speed;

    initializeMarker() ;
    publishMarkerAt( puppyPosition ) ;

    ros::Rate rate(50);   // Or other rate.
    ros::Time currentTime, prevTime = ros::Time::now() ;
    while (ros::ok()){
        ros::spinOnce();
        // Your node's code goes here.
        // Calculate new position of the dog
        currentTime = ros::Time::now() ;
        ros::Duration timeElapsed = currentTime - prevTime ;
        prevTime = currentTime ;

        //if(virtualLeaderInfoReceived&&virtualLeaderSpeedInfoReceived ){
        // u

         puppyPosition.x+=ux_vector*puppySpeed.data*timeElapsed.toSec();
         puppyPosition.y+=uy_vector*puppySpeed.data*timeElapsed.toSec();

        // Publish a marke at the position of the master.

        pubPos.publish(puppyPosition) ;
        pubSpeed.publish(puppySpeed) ;

        publishMarkerAt( puppyPosition ) ;



        rate.sleep();
    }
}
